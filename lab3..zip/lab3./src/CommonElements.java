import java.util.HashSet;

public class CommonElements {
    public static void main(String[] args) {
        String[] a = {"java", "test", "university"};
        String[] b = {"car", "university", "plane"};

        findCommonElements(a, b);
    }

    public static void findCommonElements(String[] a, String[] b) {
        HashSet<String> setA = new HashSet<>();
        HashSet<String> commonElements = new HashSet<>();

        for (String element : a) {
            setA.add(element);
        }

        for (String element : b) {
            if (setA.contains(element)) {
                commonElements.add(element);
            }
        }

        System.out.println("Common Elements: " + commonElements);
    }
}

