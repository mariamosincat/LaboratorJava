class Animal {
    public void eat() {
        System.out.println("The animal is eating something.");
    }

    public void sound() {
        System.out.println("The animal makes a sound.");
    }
}

class Lion extends Animal {
    @Override
    public void eat() {
        System.out.println("The lion eats meat.");
    }

    @Override
    public void sound() {
        System.out.println("The lion roars.");
    }
}

class Tiger extends Animal {
    @Override
    public void eat() {
        System.out.println("The tiger eats meat and occasionally hunts in the wild.");
    }

    @Override
    public void sound() {
        System.out.println("The tiger growls.");
    }
}

class Panther extends Animal {
    @Override
    public void eat() {
        System.out.println("The panther eats a variety of small to medium-sized prey.");
    }

    @Override
    public void sound() {
        System.out.println("The panther makes a distinctive vocalization.");
    }
}

public class Main {
    public static void main(String[] args) {
        Lion lion = new Lion();
        Tiger tiger = new Tiger();
        Panther panther = new Panther();

        System.out.println("Lion:");
        lion.eat();
        lion.sound();

        System.out.println("\nTiger:");
        tiger.eat();
        tiger.sound();

        System.out.println("\nPanther:");
        panther.eat();
        panther.sound();
    }
}