class Dog {
    private String name;
    private String breed;

    // Constructor care initializează proprietățile
    public Dog(String name, String breed) {
        this.name = name;
        this.breed = breed;
    }

    // Getter pentru nume
    public String getName() {
        return name;
    }

    // Setter pentru nume
    public void setName(String name) {
        this.name = name;
    }

    // Getter pentru rasă
    public String getBreed() {
        return breed;
    }

    // Setter pentru rasă
    public void setBreed(String breed) {
        this.breed = breed;
    }
}

public class Main {
    public static void main(String[] args) {
        // Creare a două instanțe ale clasei Dog
        Dog dog1 = new Dog("Buddy", "Golden Retriever");
        Dog dog2 = new Dog("Max", "Labrador");

        // Afisarea informatiilor initiale
        System.out.println("Initial Information:");
        displayDogInformation(dog1);
        displayDogInformation(dog2);

        // Modificarea proprietăților folosind setter-ele
        dog1.setName("Charlie");
        dog1.setBreed("German Shepherd");

        dog2.setName("Rocky");
        dog2.setBreed("Beagle");

        // Afisarea informatiilor dupa modificari
        System.out.println("\nInformation After Modifications:");
        displayDogInformation(dog1);
        displayDogInformation(dog2);
    }

    // Metoda pentru afișarea informațiilor despre un câine
    public static void displayDogInformation(Dog dog) {
        System.out.println("Name: " + dog.getName());
        System.out.println("Breed: " + dog.getBreed());
        System.out.println("---------------------------");
    }
}
