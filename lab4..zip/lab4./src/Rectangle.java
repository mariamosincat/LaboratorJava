class Rectangle {
    private double width;
    private double length;

    // Constructor
    public Rectangle(double width, double length) {
        this.width = width;
        this.length = length;
    }

    // Getter pentru latime
    public double getWidth() {
        return width;
    }

    // Setter pentru latime
    public void setWidth(double width) {
        this.width = width;
    }

    // Getter pentru lungime
    public double getLength() {
        return length;
    }

    // Setter pentru lungime
    public void setLength(double length) {
        this.length = length;
    }

    // Metoda pentru calculul ariei
    public double calculateArea() {
        return width * length;
    }

    // Metoda pentru calculul perimetrului
    public double calculatePerimeter() {
        return 2 * (width + length);
    }
}

public class Main {
    public static void main(String[] args) {
        // Creare a unei instanțe de Rectangle
        Rectangle rectangle = new Rectangle(5.0, 10.0);

        // Afișare informații inițiale
        displayRectangleInfo(rectangle);

        // Modificare dimensiuni folosind setter-ele
        rectangle.setWidth(7.0);
        rectangle.setLength(12.0);

        // Afișare informații actualizate
        displayRectangleInfo(rectangle);
    }

    // Metoda pentru afișarea informațiilor despre un Rectangle
    public static void displayRectangleInfo(Rectangle rectangle) {
        System.out.println("Width: " + rectangle.getWidth());
        System.out.println("Length: " + rectangle.getLength());
        System.out.println("Area: " + rectangle.calculateArea());
        System.out.println("Perimeter: " + rectangle.calculatePerimeter());
        System.out.println("---------------------------");
    }
}
