public class SumOfDigits {
    public static void main(String[] args) {
        // Test Data
        int input = 254;
        System.out.println("Input: " + input);
        System.out.println("Expected Output: Sum is " + calculateSumOfDigits(input));
    }

    public static int calculateSumOfDigits(int number) {
        int sum = 0;

        // Se iterează prin cifrele numărului și se adaugă la sumă
        while (number != 0) {
            sum += number % 10;  // Se adaugă ultima cifră
            number /= 10;        // Se elimină ultima cifră
        }

        return sum;
    }
}
