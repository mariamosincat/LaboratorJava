class Person {
    private String name;
    private String email;

    public Person(String name, String email) {
        this.name = name;
        this.email = email;
    }

    // Getter pentru nume
    public String getName() {
        return name;
    }

    // Setter pentru nume
    public void setName(String name) {
        this.name = name;
    }

    // Getter pentru email
    public String getEmail() {
        return email;
    }

    // Setter pentru email
    public void setEmail(String email) {
        this.email = email;
    }
}

class Student extends Person {
    private int[] grades;

    public Student(String name, String email, int[] grades) {
        super(name, email);
        this.grades = grades;
    }

    // Getter pentru note
    public int[] getGrades() {
        return grades;
    }

    // Setter pentru note
    public void setGrades(int[] grades) {
        this.grades = grades;
    }
}

class Professor extends Person {
    private String[] courses;

    public Professor(String name, String email, String[] courses) {
        super(name, email);
        this.courses = courses;
    }

    // Getter pentru cursuri
    public String[] getCourses() {
        return courses;
    }

    // Setter pentru cursuri
    public void setCourses(String[] courses) {
        this.courses = courses;
    }
}

public class Main {
    public static void main(String[] args) {
        // Instantierea obiectelor
        Person person = new Person("John Doe", "john.doe@example.com");
        Student student = new Student("Alice Smith", "alice.smith@example.com", new int[]{85, 90, 78});
        Professor professor = new Professor("Dr. Johnson", "dr.johnson@example.com", new String[]{"Math", "Physics"});

        // Afișarea informațiilor comune și specifice fiecărui obiect
        displayPersonInfo(person);
        displayStudentInfo(student);
        displayProfessorInfo(professor);
    }

    // Metoda pentru afișarea informațiilor despre un obiect Person
    public static void displayPersonInfo(Person person) {
        System.out.println("Person - Name: " + person.getName() + ", Email: " + person.getEmail());
    }

    // Metoda pentru afișarea informațiilor despre un obiect Student
    public static void displayStudentInfo(Student student) {
        System.out.println("Student - Name: " + student.getName() + ", Email: " + student.getEmail());
        System.out.println("Grades: " + java.util.Arrays.toString(student.getGrades()));
    }

    // Metoda pentru afișarea informațiilor despre un obiect Professor
    public static void displayProfessorInfo(Professor professor) {
        System.out.println("Professor - Name: " + professor.getName() + ", Email: " + professor.getEmail());
        System.out.println("Courses: " + java.util.Arrays.toString(professor.getCourses()));
    }
}