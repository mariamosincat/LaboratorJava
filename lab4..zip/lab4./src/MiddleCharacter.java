public class MiddleCharacter {
    public static void main(String[] args) {
        // Test Data
        String input = "masina";
        System.out.println("Input: " + input);
        System.out.println("Expected Output: " + getMiddleCharacters(input));
    }

    public static String getMiddleCharacters(String input) {
        int length = input.length();

        // Verificăm dacă lungimea cuvântului este pară sau impară
        if (length % 2 == 0) {
            // Cuvânt cu număr par de litere
            int middleIndex1 = length / 2 - 1;
            int middleIndex2 = length / 2;
            return input.substring(middleIndex1, middleIndex2 + 1);
        } else {
            // Cuvânt cu număr impar de litere
            int middleIndex = length / 2;
            return Character.toString(input.charAt(middleIndex));
        }
    }
}